import { Bot, InlineKeyboard, type Context } from "grammy";
import { logger } from "../lib/logger";
import {
  confirmPayment,
  createPaymentOrder,
  createSupportTicket,
  deliverOrder,
  getOrder,
  getPaymentDestination,
  getProduct,
  getSupportTicket,
  getWalletBalance,
  listOpenSupportTickets,
  listOrdersByStatus,
  markSupportTicketReplied,
  payWithWallet,
  products,
  recordSupportViolation,
  rejectPayment,
  reportPayment,
  setPaymentDestination,
} from "./store";
import { hasProhibitedSupportLanguage } from "./moderation";

type PaymentMethod = "vodafone_cash" | "instapay";

type PendingInput =
  | { kind: "topup_amount"; method: PaymentMethod }
  | { kind: "support_message" }
  | { kind: "payment_screenshot"; orderId: number }
  | { kind: "delivery"; orderId: number }
  | { kind: "payment_destination"; method: PaymentMethod }
  | { kind: "support_reply"; ticketId: number };

const pendingInputs = new Map<number, PendingInput>();
const purchaseLock = new Map<number, number>();
const PURCHASE_COOLDOWN_MS = 3_000;

function canPurchase(telegramUserId: number) {
  const now = Date.now();

  for (const [userId, lastAttempt] of purchaseLock) {
    if (now - lastAttempt > PURCHASE_COOLDOWN_MS) {
      purchaseLock.delete(userId);
    }
  }

  const lastAttempt = purchaseLock.get(telegramUserId);
  if (lastAttempt !== undefined && now - lastAttempt <= PURCHASE_COOLDOWN_MS) {
    return false;
  }

  purchaseLock.set(telegramUserId, now);
  return true;
}

const homeKeyboard = () =>
  new InlineKeyboard()
    .text("🏰 المتجر", "menu:store")
    .text("💰 المحفظة", "menu:wallet")
    .row()
    .text("👤 حسابي", "menu:account")
    .text("🛎 الدعم", "menu:support");

const paymentMethodLabel: Record<PaymentMethod, string> = {
  vodafone_cash: "فودافون كاش",
  instapay: "إنستا باي",
};

function money(amount: number) {
  return `${new Intl.NumberFormat("ar-EG", {
    maximumFractionDigits: 0,
  }).format(amount)} جنيه مصري`;
}

function normalizeDigits(value: string) {
  return value
    .replace(/[٠-٩]/g, (digit) =>
      String(digit.charCodeAt(0) - "٠".charCodeAt(0)),
    )
    .replace(/[۰-۹]/g, (digit) =>
      String(digit.charCodeAt(0) - "۰".charCodeAt(0)),
    );
}

function getAdminId() {
  const adminId = Number(process.env["ADMIN_TELEGRAM_ID"]);

  if (!Number.isSafeInteger(adminId) || adminId <= 0) {
    throw new Error("ADMIN_TELEGRAM_ID must be set to a valid Telegram user ID.");
  }

  return adminId;
}

function isAdmin(telegramUserId: number, adminId: number) {
  return telegramUserId === adminId;
}

async function notifyAdmin(
  bot: Bot,
  adminId: number,
  message: string,
  keyboard?: InlineKeyboard,
) {
  try {
    await bot.api.sendMessage(adminId, message, {
      ...(keyboard ? { reply_markup: keyboard } : {}),
    });
  } catch (error) {
    logger.warn({ err: error }, "Could not send a Telegram notification to the admin");
  }
}

async function notifyAdminWithPhoto(
  bot: Bot,
  adminId: number,
  photoFileId: string,
  caption: string,
  keyboard: InlineKeyboard,
) {
  try {
    await bot.api.sendPhoto(adminId, photoFileId, {
      caption,
      reply_markup: keyboard,
    });
  } catch (error) {
    logger.warn({ err: error }, "Could not send a payment screenshot to the admin");
  }
}

async function showStore(ctx: Context) {
  const keyboard = new InlineKeyboard();

  for (const product of products) {
    keyboard
      .text(`${product.name} — ${money(product.priceEgp)}`, `product:${product.id}`)
      .row();
  }

  keyboard.text("العودة للقائمة الرئيسية", "menu:home");

  await ctx.reply(
    "🏰 متجر القلعة الفاخرة\n\nاختر الحساب الذي يناسبك:",
    { reply_markup: keyboard },
  );
}

async function showProduct(
  ctx: Context,
  productId: string,
) {
  const product = getProduct(productId);
  if (!product) {
    await ctx.reply("هذا المنتج غير متاح حاليًا.", {
      reply_markup: homeKeyboard(),
    });
    return;
  }

  const keyboard = new InlineKeyboard()
    .text("الشراء من المحفظة", `buy:wallet:${product.id}`)
    .row()
    .text("الدفع عبر فودافون كاش", `buy:vodafone_cash:${product.id}`)
    .row()
    .text("الدفع عبر إنستا باي", `buy:instapay:${product.id}`)
    .row()
    .text("العودة للمتجر", "menu:store");

  await ctx.reply(
    `✨ ${product.name}\n${product.details}\n\nالسعر: ${money(product.priceEgp)}`,
    { reply_markup: keyboard },
  );
}

async function showWallet(
  ctx: Context,
  telegramUserId: number,
) {
  const balance = await getWalletBalance(telegramUserId);
  const keyboard = new InlineKeyboard()
    .text("طلب شحن عبر فودافون كاش", "wallet:topup:vodafone_cash")
    .row()
    .text("طلب شحن عبر إنستا باي", "wallet:topup:instapay")
    .row()
    .text("العودة للقائمة الرئيسية", "menu:home");

  await ctx.reply(
    `💰 محفظتك\n\nالرصيد الحالي: ${money(balance)}\n\nيمكنك طلب الشحن يدويًا، وسيُضاف الرصيد بعد مراجعة الإدارة للتحويل.`,
    { reply_markup: keyboard },
  );
}

async function showAdminPanel(
  ctx: Context,
) {
  const keyboard = new InlineKeyboard()
    .text("مراجعة التحويلات", "admin:payments")
    .row()
    .text("تسليم الحسابات المدفوعة", "admin:deliveries")
    .row()
    .text("رسائل الدعم", "admin:support")
    .row()
    .text("إعدادات الدفع", "admin:settings")
    .row()
    .text("العودة للقائمة الرئيسية", "menu:home");

  await ctx.reply(
    "لوحة الإدارة\n\nيمكنك مراجعة التحويلات، شحن المحافظ، تسليم الحسابات، والرد على الدعم.",
    { reply_markup: keyboard },
  );
}

async function beginManualPayment(
  ctx: Context,
  telegramUserId: number,
  kind: "purchase" | "topup",
  method: PaymentMethod,
  amountEgp: number,
  productName: string,
  productId?: string,
) {
  const destination = await getPaymentDestination(method);

  if (!destination) {
    await ctx.reply(
      `بيانات ${paymentMethodLabel[method]} غير مضافة بعد. تواصل مع الدعم أو اطلب من الإدارة ضبط بيانات التحويل من /admin.`,
      { reply_markup: homeKeyboard() },
    );
    return;
  }

  const order = await createPaymentOrder({
    telegramUserId,
    kind,
    productName,
    amountEgp,
    paymentMethod: method,
    ...(productId ? { productId } : {}),
  });

  const keyboard = new InlineKeyboard()
    .text("أبلغت عن التحويل", `payment:report:${order.id}`)
    .row()
    .text("التواصل مع الدعم", "menu:support");

  await ctx.reply(
    `تم إنشاء الطلب رقم #${order.id}.\n\n` +
      `المبلغ: ${money(amountEgp)}\n` +
      `طريقة الدفع: ${paymentMethodLabel[method]}\n` +
      `بيانات التحويل: ${destination}\n\n` +
      `بعد التحويل اضغط «أبلغت عن التحويل». ستراجع الإدارة العملية يدويًا.`,
    { reply_markup: keyboard },
  );
}

export function startTelegramBot(): (() => void) | undefined {
  if (process.env["ENABLE_TELEGRAM_BOT"] !== "true") {
    logger.info("Telegram bot polling is disabled");
    return undefined;
  }

  const token = process.env["TELEGRAM_BOT_TOKEN"];

  if (!token) {
    throw new Error(
      "TELEGRAM_BOT_TOKEN is required when ENABLE_TELEGRAM_BOT is true.",
    );
  }

  const adminId = getAdminId();
  const bot = new Bot(token);

  bot.command("start", async (ctx) => {
    const greeting = isAdmin(ctx.from?.id ?? 0, adminId)
      ? "مرحبًا بك في متجر القلعة الفاخرة. يمكنك فتح لوحة الإدارة باستخدام /admin."
      : "مرحبًا بك في متجر القلعة الفاخرة لحسابات Conquerors Golden Age. اختر الخدمة التي تريدها من الأزرار:";

    await ctx.reply(greeting, { reply_markup: homeKeyboard() });
  });

  bot.command("help", (ctx) => {
    const adminHint = isAdmin(ctx.from?.id ?? 0, adminId)
      ? "\n\nللوحة الإدارة: /admin"
      : "";

    return ctx.reply(
      `اختر المتجر لتصفح الحسابات، والمحفظة لعرض رصيدك أو طلب شحنه، وحسابي لمراجعة بياناتك، أو الدعم لإرسال رسالة إلى الإدارة.${adminHint}`,
      { reply_markup: homeKeyboard() },
    );
  });

  bot.command("admin", async (ctx) => {
    if (!isAdmin(ctx.from?.id ?? 0, adminId)) {
      await ctx.reply("هذا الأمر مخصص للإدارة فقط.");
      return;
    }

    await showAdminPanel(ctx);
  });

  bot.on("callback_query:data", async (ctx) => {
    const data = ctx.callbackQuery.data;
    await ctx.answerCallbackQuery();
    const telegramUserId = ctx.from?.id;
    if (telegramUserId === undefined) {
      return;
    }

    if (data === "menu:home") {
      await ctx.reply("القائمة الرئيسية — اختر ما تريد:", {
        reply_markup: homeKeyboard(),
      });
      return;
    }

    if (data === "menu:store") {
      await showStore(ctx);
      return;
    }

    if (data === "menu:wallet") {
      await showWallet(ctx, telegramUserId);
      return;
    }

    if (data === "menu:account") {
      const balance = await getWalletBalance(telegramUserId);
      await ctx.reply(
        `👤 حسابي\n\nمعرّف حسابك: ${telegramUserId}\nرصيد المحفظة: ${money(balance)}`,
        { reply_markup: homeKeyboard() },
      );
      return;
    }

    if (data === "menu:support") {
      pendingInputs.set(telegramUserId, { kind: "support_message" });
      await ctx.reply("اكتب رسالتك للدعم في رسالة واحدة، وسنرسلها إلى الإدارة.");
      return;
    }

    if (data === "menu:payment_destination:vodafone_cash") {
      if (!isAdmin(telegramUserId, adminId)) {
        await ctx.reply("هذا الإجراء مخصص للإدارة فقط.");
        return;
      }

      pendingInputs.set(telegramUserId, {
        kind: "payment_destination",
        method: "vodafone_cash",
      });
      await ctx.reply("أرسل رقم فودافون كاش الذي تريد استقبال المدفوعات عليه.");
      return;
    }

    if (data.startsWith("product:")) {
      await showProduct(ctx, data.slice("product:".length));
      return;
    }

    if (data.startsWith("buy:")) {
      const [, method, productId] = data.split(":");
      const product = getProduct(productId ?? "");

      if (!product || !method) {
        await ctx.reply("تعذر العثور على هذا المنتج.");
        return;
      }

      if (!canPurchase(telegramUserId)) {
        await ctx.reply("انتظر 3 ثوانٍ قبل محاولة شراء أخرى.");
        return;
      }

      if (method === "wallet") {
        const result = await payWithWallet({
          telegramUserId,
          productId: product.id,
          productName: product.name,
          amountEgp: product.priceEgp,
        });

        if (!result.paid) {
          await ctx.reply(
            `رصيدك الحالي ${money(result.balance)} ولا يكفي لشراء هذا الحساب. يمكنك شحن المحفظة أو اختيار وسيلة دفع مباشرة.`,
            { reply_markup: new InlineKeyboard().text("فتح المحفظة", "menu:wallet") },
          );
          return;
        }

        await ctx.reply(
          `تم تأكيد الشراء من المحفظة للطلب #${result.order.id}. ستراجع الإدارة الطلب وترسل بيانات الحساب بعد التجهيز.`,
          { reply_markup: homeKeyboard() },
        );
        await notifyAdmin(
          bot,
          adminId,
          `طلب جديد مدفوع من المحفظة #${result.order.id}\nالمنتج: ${product.name}\nالمبلغ: ${money(product.priceEgp)}\nمعرّف العميل: ${telegramUserId}`,
          new InlineKeyboard().text(
            `تسليم الحساب #${result.order.id}`,
            `admin:deliver:${result.order.id}`,
          ),
        );
        return;
      }

      if (method === "vodafone_cash" || method === "instapay") {
        await beginManualPayment(
          ctx,
          telegramUserId,
          "purchase",
          method,
          product.priceEgp,
          product.name,
          product.id,
        );
      }

      return;
    }

    if (data.startsWith("wallet:topup:")) {
      const method = data.slice("wallet:topup:".length);
      if (method !== "vodafone_cash" && method !== "instapay") {
        await ctx.reply("طريقة الدفع غير متاحة.");
        return;
      }

      pendingInputs.set(telegramUserId, {
        kind: "topup_amount",
        method,
      });
      await ctx.reply("أرسل مبلغ الشحن بالجنيه المصري كرقم صحيح، من 1 إلى 100000.");
      return;
    }

    if (data.startsWith("payment:report:")) {
      const orderId = Number(data.slice("payment:report:".length));
      if (!Number.isSafeInteger(orderId) || orderId <= 0) {
        await ctx.reply("رقم الطلب غير صالح.");
        return;
      }

      const order = await getOrder(orderId);
      if (
        !order ||
        order.telegramUserId !== telegramUserId ||
        order.status !== "awaiting_payment"
      ) {
        await ctx.reply("هذا الطلب غير متاح للإبلاغ عن تحويله.");
        return;
      }

      pendingInputs.set(telegramUserId, {
        kind: "payment_screenshot",
        orderId,
      });
      await ctx.reply(
        `أرسل صورة واضحة لإيصال التحويل الخاص بالطلب #${order.id}. لن يصل الطلب إلى الإدارة للمراجعة حتى ترسل الصورة.`,
      );
      return;
    }

    if (data.startsWith("admin:")) {
      if (!isAdmin(telegramUserId, adminId)) {
        await ctx.reply("هذا الإجراء مخصص للإدارة فقط.");
        return;
      }

      const action = data.slice("admin:".length);

      if (action === "payments") {
        const orders = await listOrdersByStatus(["payment_reported"]);
        if (orders.length === 0) {
          await ctx.reply("لا توجد تحويلات بانتظار المراجعة.");
          return;
        }

        for (const order of orders) {
          const keyboard = new InlineKeyboard()
            .text("تأكيد الدفع", `admin:confirm:${order.id}`)
            .text("رفض الإبلاغ", `admin:reject:${order.id}`);
          const details =
            `طلب #${order.id} — ${order.kind === "topup" ? "شحن محفظة" : "شراء حساب"}\n` +
            `${order.productName}\n${money(order.amountEgp)}\n` +
            `العميل: ${order.telegramUserId}`;

          if (order.paymentScreenshotFileId) {
            try {
              await ctx.replyWithPhoto(order.paymentScreenshotFileId, {
                caption: details,
                reply_markup: keyboard,
              });
            } catch (error) {
              logger.warn(
                { err: error, orderId: order.id },
                "Could not display a payment screenshot to the admin",
              );
              await ctx.reply(
                `${details}\nتعذر عرض صورة الإيصال؛ راجع إشعار الصورة السابق إن وُجد.`,
                { reply_markup: keyboard },
              );
            }
          } else {
            await ctx.reply(
              `${details}\nلا توجد صورة إيصال مرفقة بهذا الطلب القديم.`,
              { reply_markup: keyboard },
            );
          }
        }
        return;
      }

      if (action === "deliveries") {
        const orders = await listOrdersByStatus(["paid"]);
        const purchases = orders.filter((order) => order.kind === "purchase");
        if (purchases.length === 0) {
          await ctx.reply("لا توجد حسابات مدفوعة بانتظار التسليم.");
          return;
        }

        for (const order of purchases) {
          await ctx.reply(
            `طلب #${order.id} — ${order.productName}\nالعميل: ${order.telegramUserId}`,
            {
              reply_markup: new InlineKeyboard().text(
                `إرسال بيانات الحساب #${order.id}`,
                `admin:deliver:${order.id}`,
              ),
            },
          );
        }
        return;
      }

      if (action === "support") {
        const tickets = await listOpenSupportTickets();
        if (tickets.length === 0) {
          await ctx.reply("لا توجد رسائل دعم مفتوحة.");
          return;
        }

        for (const ticket of tickets) {
          await ctx.reply(
            `رسالة دعم #${ticket.id}\n` +
              `العميل: ${ticket.username ? `@${ticket.username}` : ticket.telegramUserId}\n` +
              `${ticket.message}`,
            {
              reply_markup: new InlineKeyboard().text(
                `الرد على #${ticket.id}`,
                `admin:reply:${ticket.id}`,
              ),
            },
          );
        }
        return;
      }

      if (action === "settings") {
        const [vodafone, instapay] = await Promise.all([
          getPaymentDestination("vodafone_cash"),
          getPaymentDestination("instapay"),
        ]);
        const keyboard = new InlineKeyboard()
          .text(
            vodafone ? "تعديل بيانات فودافون كاش" : "إضافة فودافون كاش",
            "menu:payment_destination:vodafone_cash",
          )
          .row()
          .text(
            instapay ? "تعديل بيانات إنستا باي" : "إضافة إنستا باي",
            "admin:set:instapay",
          );
        await ctx.reply(
          `إعدادات التحويل\n\nفودافون كاش: ${vodafone ? "مضاف" : "غير مضاف"}\nإنستا باي: ${instapay ? "مضاف" : "غير مضاف"}\n\nأضف بيانات الاستلام ليتمكن العملاء من الدفع.`,
          { reply_markup: keyboard },
        );
        return;
      }

      const [, verb, rawId] = action.split(":");
      const orderId = Number(rawId);
      if (
        (verb === "confirm" || verb === "reject" || verb === "deliver") &&
        Number.isSafeInteger(orderId) &&
        orderId > 0
      ) {
        if (verb === "confirm") {
          const order = await confirmPayment(orderId);
          if (!order) {
            await ctx.reply("تمت مراجعة هذا الطلب مسبقًا أو لم يعد بانتظار المراجعة.");
            return;
          }

          if (order.kind === "topup") {
            const balance = await getWalletBalance(order.telegramUserId);
            await ctx.api.sendMessage(
              order.telegramUserId,
              `تم تأكيد التحويل للطلب #${order.id} وإضافة ${money(order.amountEgp)} إلى محفظتك.\nرصيدك الآن: ${money(balance)}.`,
            );
            await ctx.reply(`تم تأكيد شحن الطلب #${order.id}.`);
            return;
          }

          await ctx.api.sendMessage(
            order.telegramUserId,
            `تم تأكيد الدفع للطلب #${order.id}. ستصلك بيانات الحساب بعد تجهيزها.`,
          );
          await ctx.reply(`تم تأكيد الطلب #${order.id}. أرسل بيانات الحساب من قائمة التسليم.`);
          await ctx.reply(
            `طلب #${order.id} — ${order.productName}\nالعميل: ${order.telegramUserId}`,
            {
              reply_markup: new InlineKeyboard().text(
                `إرسال بيانات الحساب #${order.id}`,
                `admin:deliver:${order.id}`,
              ),
            },
          );
          return;
        }

        if (verb === "reject") {
          const order = await rejectPayment(orderId);
          if (!order) {
            await ctx.reply("تمت معالجة هذا الطلب مسبقًا.");
            return;
          }

          await ctx.api.sendMessage(
            order.telegramUserId,
            `تعذر تأكيد التحويل للطلب #${order.id}. تواصل مع الدعم إذا كنت قد أرسلت المبلغ بالفعل.`,
            { reply_markup: homeKeyboard() },
          );
          await ctx.reply(`تم رفض الإبلاغ عن التحويل للطلب #${order.id}.`);
          return;
        }

        if (verb === "deliver") {
          const order = await getOrder(orderId);
          if (!order || order.kind !== "purchase" || order.status !== "paid") {
            await ctx.reply("هذا الطلب غير جاهز للتسليم.");
            return;
          }

          pendingInputs.set(telegramUserId, {
            kind: "delivery",
            orderId,
          });
          await ctx.reply(
            `أرسل الآن بيانات الحساب للطلب #${orderId} في رسالة واحدة. ستُرسل مباشرة إلى العميل ولن تُحفظ في سجل الطلب.`,
          );
          return;
        }
      }

      if (verb === "reply" && Number.isSafeInteger(orderId) && orderId > 0) {
        const ticket = await getSupportTicket(orderId);
        if (!ticket || ticket.status !== "open") {
          await ctx.reply("رسالة الدعم هذه مغلقة أو غير موجودة.");
          return;
        }

        pendingInputs.set(telegramUserId, {
          kind: "support_reply",
          ticketId: orderId,
        });
        await ctx.reply(`اكتب ردك على رسالة الدعم #${orderId}.`);
        return;
      }

      if (verb === "set" && (rawId === "vodafone_cash" || rawId === "instapay")) {
        pendingInputs.set(telegramUserId, {
          kind: "payment_destination",
          method: rawId,
        });
        await ctx.reply(
          `أرسل بيانات الاستلام الخاصة بـ${paymentMethodLabel[rawId]} كما تريد أن تظهر للعملاء.`,
        );
      }

      return;
    }
  });

  bot.on("message:photo", async (ctx) => {
    const telegramUserId = ctx.from.id;
    const pending = pendingInputs.get(telegramUserId);

    if (!pending) {
      await ctx.reply(
        "لاستكمال الإبلاغ عن تحويل، اضغط أولًا «أبلغت عن التحويل» في رسالة الطلب ثم أرسل صورة الإيصال.",
      );
      return;
    }

    if (pending.kind !== "payment_screenshot") {
      await ctx.reply("أكمل الإجراء الحالي بإرسال رسالة نصية، وليس صورة.");
      return;
    }

    const photos = ctx.message.photo;
    const largestPhoto = photos[photos.length - 1];
    if (!largestPhoto) {
      await ctx.reply("لم أتمكن من قراءة الصورة. أرسل صورة الإيصال مرة أخرى.");
      return;
    }

    const order = await reportPayment(
      pending.orderId,
      telegramUserId,
      largestPhoto.file_id,
    );
    if (!order) {
      pendingInputs.delete(telegramUserId);
      await ctx.reply("لم يعد هذا الطلب بانتظار صورة الإيصال أو تمت مراجعته.");
      return;
    }

    pendingInputs.delete(telegramUserId);
    const caption =
      `إيصال تحويل جديد للطلب #${order.id}\n` +
      `النوع: ${order.kind === "topup" ? "شحن محفظة" : "شراء حساب"}\n` +
      `المنتج: ${order.productName}\n` +
      `المبلغ: ${money(order.amountEgp)}\n` +
      `الوسيلة: ${paymentMethodLabel[order.paymentMethod as PaymentMethod] ?? order.paymentMethod}\n` +
      `معرّف العميل: ${order.telegramUserId}`;

    await ctx.reply(
      `تم استلام صورة الإيصال للطلب #${order.id}. ستراجع الإدارة التحويل يدويًا.`,
    );
    await notifyAdminWithPhoto(
      bot,
      adminId,
      largestPhoto.file_id,
      caption,
      new InlineKeyboard().text("مراجعة التحويلات", "admin:payments"),
    );
  });

  bot.on("message:text", async (ctx) => {
    const telegramUserId = ctx.from.id;
    const text = ctx.message.text.trim();
    const pending = pendingInputs.get(telegramUserId);

    if (!pending) {
      await ctx.reply("استخدم أزرار القائمة للتنقل بين أقسام المتجر.", {
        reply_markup: homeKeyboard(),
      });
      return;
    }

    if (text.startsWith("/")) {
      return;
    }

    if (pending.kind === "payment_screenshot") {
      await ctx.reply("أرسل صورة إيصال التحويل لإكمال الإبلاغ عن الطلب.");
      return;
    }

    pendingInputs.delete(telegramUserId);

    if (pending.kind === "topup_amount") {
      const amountText = normalizeDigits(text);
      if (!/^\d{1,6}$/.test(amountText)) {
        await ctx.reply("أرسل مبلغًا صحيحًا بالأرقام، من 1 إلى 100000 جنيه.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      const amountEgp = Number(amountText);
      if (amountEgp < 1 || amountEgp > 100000) {
        await ctx.reply("المبلغ يجب أن يكون بين 1 و100000 جنيه.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      await beginManualPayment(
        ctx,
        telegramUserId,
        "topup",
        pending.method,
        amountEgp,
        "شحن المحفظة",
      );
      return;
    }

    if (pending.kind === "support_message") {
      if (
        !isAdmin(telegramUserId, adminId) &&
        hasProhibitedSupportLanguage(text)
      ) {
        const warnCount = await recordSupportViolation(telegramUserId);
        pendingInputs.set(telegramUserId, pending);
        await ctx.reply(
          `يرجى استخدام لغة مناسبة في رسائل الدعم. تم تسجيل تنبيه رقم ${warnCount}، ولم يتم حظر حسابك.`,
        );
        return;
      }

      if (text.length > 3000) {
        await ctx.reply("اختصر رسالتك إلى 3000 حرف كحد أقصى.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      const ticket = await createSupportTicket({
        telegramUserId,
        username: ctx.from.username,
        message: text,
      });
      await ctx.reply(`تم إرسال رسالتك للدعم برقم #${ticket.id}.`);
      await notifyAdmin(
        bot,
        adminId,
        `رسالة دعم #${ticket.id}\n` +
          `العميل: ${ctx.from.username ? `@${ctx.from.username}` : telegramUserId}\n` +
          `${text}`,
        new InlineKeyboard().text(
          `الرد على #${ticket.id}`,
          `admin:reply:${ticket.id}`,
        ),
      );
      return;
    }

    if (pending.kind === "payment_destination") {
      if (text.length < 3 || text.length > 160) {
        await ctx.reply("البيانات غير صالحة. أرسل رقمًا أو عنوانًا بين 3 و160 حرفًا.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      await setPaymentDestination(pending.method, text);
      await ctx.reply(
        `تم حفظ بيانات ${paymentMethodLabel[pending.method]}. ستظهر هذه البيانات للعملاء عند اختيار طريقة الدفع.`,
        { reply_markup: homeKeyboard() },
      );
      return;
    }

    if (pending.kind === "support_reply") {
      if (text.length > 3000) {
        await ctx.reply("اختصر الرد إلى 3000 حرف كحد أقصى.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      const ticket = await getSupportTicket(pending.ticketId);
      if (!ticket || ticket.status !== "open") {
        await ctx.reply("رسالة الدعم هذه لم تعد مفتوحة.");
        return;
      }

      await ctx.api.sendMessage(
        ticket.telegramUserId,
        `رد الدعم على رسالتك #${ticket.id}:\n\n${text}`,
        { reply_markup: homeKeyboard() },
      );
      await markSupportTicketReplied(ticket.id);
      await ctx.reply(`تم إرسال الرد على رسالة الدعم #${ticket.id}.`);
      return;
    }

    if (pending.kind === "delivery") {
      if (text.length > 3000) {
        await ctx.reply("اختصر بيانات الحساب إلى 3000 حرف كحد أقصى.");
        pendingInputs.set(telegramUserId, pending);
        return;
      }

      const order = await getOrder(pending.orderId);
      if (!order || order.kind !== "purchase" || order.status !== "paid") {
        await ctx.reply("هذا الطلب لم يعد جاهزًا للتسليم.");
        return;
      }

      await ctx.api.sendMessage(
        order.telegramUserId,
        `بيانات حسابك للطلب #${order.id} — ${order.productName}:\n\n${text}\n\nاحتفظ بهذه البيانات في مكان آمن.`,
      );
      await deliverOrder(order.id);
      await ctx.reply(`تم إرسال بيانات الحساب للطلب #${order.id}.`);
    }
  });

  bot.catch((error) => {
    logger.error({ err: error }, "Telegram update handler failed");
  });

  void bot
    .start({
      onStart: ({ username }) => {
        logger.info({ username }, "Telegram bot polling started");
      },
    })
    .catch((error: unknown) => {
      logger.error({ err: error }, "Telegram bot polling stopped unexpectedly");
      process.exit(1);
    });

  return () => {
    pendingInputs.clear();
    bot.stop();
  };
}
