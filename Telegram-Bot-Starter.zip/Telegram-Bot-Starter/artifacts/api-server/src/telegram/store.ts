import { and, desc, eq, inArray, sql } from "drizzle-orm";
import {
  db,
  storeOrders,
  storePaymentSettings,
  storeSupportTickets,
  storeUserModeration,
  storeWalletTransactions,
  storeWallets,
} from "@workspace/db";

export const products = [
  {
    id: "castle-30",
    name: "قلعة هيبة 5 — مستوى 30",
    details: "فل ماكس أبطال وعتاد",
    priceEgp: 4000,
  },
  {
    id: "castle-28",
    name: "قلعة هيبة 4 — مستوى 28",
    details: "جاهزة للحروب والغزوات",
    priceEgp: 2500,
  },
  {
    id: "castle-26",
    name: "قلعة هيبة 3 — مستوى 26",
    details: "حساب قوي ونظيف",
    priceEgp: 1500,
  },
  {
    id: "farm",
    name: "قلعة مزارع",
    details: "موارد وجنود فل",
    priceEgp: 600,
  },
  {
    id: "starter",
    name: "حساب تصفير",
    details: "بداية قوية بجواهر",
    priceEgp: 300,
  },
] as const;

export type ProductId = (typeof products)[number]["id"];

export function getProduct(productId: string) {
  return products.find((product) => product.id === productId);
}

export async function getWalletBalance(telegramUserId: number) {
  const [wallet] = await db
    .select({ balance: storeWallets.balanceEgp })
    .from(storeWallets)
    .where(eq(storeWallets.telegramUserId, telegramUserId))
    .limit(1);

  return wallet?.balance ?? 0;
}

export async function createPaymentOrder(input: {
  telegramUserId: number;
  kind: "purchase" | "topup";
  productId?: string;
  productName: string;
  amountEgp: number;
  paymentMethod: "vodafone_cash" | "instapay";
}) {
  const [order] = await db
    .insert(storeOrders)
    .values({
      ...input,
      status: "awaiting_payment",
    })
    .returning();

  return order;
}

export async function payWithWallet(input: {
  telegramUserId: number;
  productId: string;
  productName: string;
  amountEgp: number;
}) {
  return db.transaction(async (tx) => {
    const [wallet] = await tx
      .select()
      .from(storeWallets)
      .where(eq(storeWallets.telegramUserId, input.telegramUserId))
      .for("update");

    const balance = wallet?.balanceEgp ?? 0;
    if (balance < input.amountEgp) {
      return { paid: false as const, balance };
    }

    await tx
      .insert(storeWallets)
      .values({
        telegramUserId: input.telegramUserId,
        balanceEgp: balance - input.amountEgp,
        updatedAt: new Date(),
      })
      .onConflictDoUpdate({
        target: storeWallets.telegramUserId,
        set: {
          balanceEgp: balance - input.amountEgp,
          updatedAt: new Date(),
        },
      });

    const [order] = await tx
      .insert(storeOrders)
      .values({
        ...input,
        kind: "purchase",
        paymentMethod: "wallet",
        status: "paid",
        paidAt: new Date(),
      })
      .returning();

    await tx.insert(storeWalletTransactions).values({
      telegramUserId: input.telegramUserId,
      amountEgp: -input.amountEgp,
      reason: `شراء الطلب #${order.id}`,
      orderId: order.id,
    });

    return { paid: true as const, balance: balance - input.amountEgp, order };
  });
}

export async function reportPayment(
  orderId: number,
  telegramUserId: number,
  screenshotFileId: string,
) {
  const [order] = await db
    .update(storeOrders)
    .set({
      status: "payment_reported",
      paymentScreenshotFileId: screenshotFileId,
      paymentScreenshotSubmittedAt: new Date(),
    })
    .where(
      and(
        eq(storeOrders.id, orderId),
        eq(storeOrders.telegramUserId, telegramUserId),
        eq(storeOrders.status, "awaiting_payment"),
      ),
    )
    .returning();

  return order;
}

export async function recordSupportViolation(telegramUserId: number) {
  const [record] = await db
    .insert(storeUserModeration)
    .values({ telegramUserId, warnCount: 1 })
    .onConflictDoUpdate({
      target: storeUserModeration.telegramUserId,
      set: {
        warnCount: sql`${storeUserModeration.warnCount} + 1`,
        updatedAt: new Date(),
      },
    })
    .returning({ warnCount: storeUserModeration.warnCount });

  return record?.warnCount ?? 1;
}

export async function getOrder(orderId: number) {
  const [order] = await db
    .select()
    .from(storeOrders)
    .where(eq(storeOrders.id, orderId))
    .limit(1);

  return order;
}

export async function listOrdersByStatus(statuses: string[], limit = 10) {
  return db
    .select()
    .from(storeOrders)
    .where(inArray(storeOrders.status, statuses))
    .orderBy(desc(storeOrders.createdAt))
    .limit(limit);
}

export async function confirmPayment(orderId: number) {
  return db.transaction(async (tx) => {
    const [order] = await tx
      .select()
      .from(storeOrders)
      .where(eq(storeOrders.id, orderId))
      .for("update");

    if (!order || order.status !== "payment_reported") {
      return null;
    }

    const newStatus = order.kind === "topup" ? "credited" : "paid";
    await tx
      .update(storeOrders)
      .set({ status: newStatus, paidAt: new Date() })
      .where(eq(storeOrders.id, orderId));

    if (order.kind === "topup") {
      await tx
        .insert(storeWallets)
        .values({
          telegramUserId: order.telegramUserId,
          balanceEgp: order.amountEgp,
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: storeWallets.telegramUserId,
          set: {
            balanceEgp: sql`${storeWallets.balanceEgp} + ${order.amountEgp}`,
            updatedAt: new Date(),
          },
        });

      await tx.insert(storeWalletTransactions).values({
        telegramUserId: order.telegramUserId,
        amountEgp: order.amountEgp,
        reason: `شحن المحفظة عبر الطلب #${order.id}`,
        orderId: order.id,
        createdByTelegramId: Number(process.env["ADMIN_TELEGRAM_ID"]),
      });
    }

    return { ...order, status: newStatus };
  });
}

export async function rejectPayment(orderId: number) {
  const [order] = await db
    .update(storeOrders)
    .set({ status: "rejected" })
    .where(
      and(
        eq(storeOrders.id, orderId),
        eq(storeOrders.status, "payment_reported"),
      ),
    )
    .returning();

  return order;
}

export async function deliverOrder(orderId: number) {
  const [order] = await db
    .update(storeOrders)
    .set({ status: "delivered", deliveredAt: new Date() })
    .where(
      and(
        eq(storeOrders.id, orderId),
        eq(storeOrders.kind, "purchase"),
        eq(storeOrders.status, "paid"),
      ),
    )
    .returning();

  return order;
}

export async function setPaymentDestination(
  method: "vodafone_cash" | "instapay",
  destination: string,
) {
  await db
    .insert(storePaymentSettings)
    .values({ method, destination, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: storePaymentSettings.method,
      set: { destination, updatedAt: new Date() },
    });
}

export async function getPaymentDestination(
  method: "vodafone_cash" | "instapay",
) {
  const [setting] = await db
    .select({ destination: storePaymentSettings.destination })
    .from(storePaymentSettings)
    .where(eq(storePaymentSettings.method, method))
    .limit(1);

  return setting?.destination;
}

export async function createSupportTicket(input: {
  telegramUserId: number;
  username?: string;
  message: string;
}) {
  const [ticket] = await db
    .insert(storeSupportTickets)
    .values({
      ...input,
      username: input.username ?? null,
    })
    .returning();

  return ticket;
}

export async function getSupportTicket(ticketId: number) {
  const [ticket] = await db
    .select()
    .from(storeSupportTickets)
    .where(eq(storeSupportTickets.id, ticketId))
    .limit(1);

  return ticket;
}

export async function listOpenSupportTickets(limit = 10) {
  return db
    .select()
    .from(storeSupportTickets)
    .where(eq(storeSupportTickets.status, "open"))
    .orderBy(desc(storeSupportTickets.createdAt))
    .limit(limit);
}

export async function markSupportTicketReplied(ticketId: number) {
  await db
    .update(storeSupportTickets)
    .set({ status: "replied" })
    .where(eq(storeSupportTickets.id, ticketId));
}
