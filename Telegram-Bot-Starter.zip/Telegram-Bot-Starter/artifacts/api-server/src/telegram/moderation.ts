const DANGEROUS_WORDS = [
  "eval",
  "exec",
  "import os",
  "subprocess",
  "rm -rf",
  "import",
  "os.system",
];

const BAD_WORDS = [
  "كس",
  "زب",
  "نيك",
  "خول",
  "علق",
  "شرموطة",
  "متناك",
  "متناكة",
  "عرص",
  "لبوة",
  "قحبة",
  "كسمك",
  "طيز",
  "خرا",
  "منيوك",
  "زامل",
  "fuck",
  "shit",
  "bitch",
  "امك",
  "أمك",
  "اختك",
  "أختك",
  "عمتك",
  "خالتك",
  "ابوك",
  "أبوك",
  "اهلك",
  "أهلك",
  "عيلتك",
  "كس اختك",
  "كس امك",
  "كس عمتك",
  "كس خالتك",
  "نيك امك",
  "نيك اختك",
  "يابن",
  "ابن مرة",
  "ابن وسخة",
  "شرموطة امك",
];

function normalizeSupportText(value: string) {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase("ar")
    .replace(/[\u0640\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآٱ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/[^\p{L}\p{N}]+/gu, " ")
    .trim();
}

const prohibitedTerms = [...DANGEROUS_WORDS, ...BAD_WORDS].map(
  normalizeSupportText,
);

export function hasProhibitedSupportLanguage(message: string) {
  const normalizedMessage = ` ${normalizeSupportText(message)} `;

  return prohibitedTerms.some(
    (term) => term.length > 0 && normalizedMessage.includes(` ${term} `),
  );
}
