---
name: Telegram store scope
description: The store's product identity, language, currency, and payment-confirmation model.
---

The Telegram bot is a luxury-themed shop for Conquerors Golden Age game accounts. All user-facing bot messages and buttons must be Arabic. Prices are in Egyptian pounds. Customers pay manually through Vodafone Cash or InstaPay, and must attach a receipt screenshot before the sole admin reviews and confirms transfers in `/admin`. In support messages, prohibited wording triggers a recorded warning only; never auto-ban.

**Why:** The user specified the product and payment workflow, then chose screenshot-required payment reports and warnings without automatic bans.

**How to apply:** Keep new storefront, wallet, support, and order flows in Arabic; preserve manual admin confirmation, require proof screenshots for new reports, and limit moderation to warnings unless the user changes the policy.
