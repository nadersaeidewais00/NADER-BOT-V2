---
name: pnpm audit behavior
description: pnpm 10 audit fixes can rewrite workspace config and select a newer major.
---

`pnpm audit --fix` in this workspace adds overrides but reserializes `pnpm-workspace.yaml`, reorders existing entries, and drops comments. Its broad `>=` override for `fast-uri` selected major version 4 even though the dependency expects version 3.

**Why:** automated remediation can create unnecessary compatibility risk and large config diffs while still producing a green audit.

**How to apply:** Keep the existing one-day minimum release age. After audit fixes, inspect the workspace config and lockfile, constrain each override to a compatible patched major, reinstall, and rerun the audit.
